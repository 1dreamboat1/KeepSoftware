import HomeContent from '@bundle:com.example.baizhankeep/entry/ets/view/home/HomeContent';
class MainIndex extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__selectIndex = new ObservedPropertySimplePU(0, this, "selectIndex");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.selectIndex !== undefined) {
            this.selectIndex = params.selectIndex;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__selectIndex.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__selectIndex.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get selectIndex() {
        return this.__selectIndex.get();
    }
    set selectIndex(newValue) {
        this.__selectIndex.set(newValue);
    }
    TabBarBuilder(index, normalIcon, selIcon, text, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/MainIndex.ets(8:5)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create(this.selectIndex === index ? selIcon : normalIcon);
            Image.debugLine("pages/MainIndex.ets(9:7)");
            Image.width(20);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(text);
            Text.debugLine("pages/MainIndex.ets(11:7)");
            Text.fontSize(10);
            Text.fontColor(this.selectIndex === index ? { "id": 16777264, "type": 10001, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" } : { "id": 16777263, "type": 10001, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Tabs.create({
                barPosition: BarPosition.End,
                index: this.selectIndex
            });
            Tabs.debugLine("pages/MainIndex.ets(18:5)");
            Tabs.onChange((index) => {
                this.selectIndex = index;
            });
            if (!isInitialRender) {
                Tabs.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new HomeContent(this, {}, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
            });
            TabContent.tabBar({ builder: () => {
                    this.TabBarBuilder.call(this, 0, { "id": 16777218, "type": 20000, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" }, { "id": 16777282, "type": 20000, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" }, "主页");
                } });
            TabContent.debugLine("pages/MainIndex.ets(23:7)");
            if (!isInitialRender) {
                //主页
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create();
            TabContent.tabBar({ builder: () => {
                    this.TabBarBuilder.call(this, 1, { "id": 16777222, "type": 20000, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" }, { "id": 16777272, "type": 20000, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" }, "成就");
                } });
            TabContent.debugLine("pages/MainIndex.ets(33:7)");
            if (!isInitialRender) {
                //成就页
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create();
            TabContent.tabBar({ builder: () => {
                    this.TabBarBuilder.call(this, 2, { "id": 16777270, "type": 20000, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" }, { "id": 16777251, "type": 20000, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" }, "个人");
                } });
            TabContent.debugLine("pages/MainIndex.ets(41:7)");
            if (!isInitialRender) {
                //个人页
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        Tabs.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new MainIndex(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=MainIndex.js.map