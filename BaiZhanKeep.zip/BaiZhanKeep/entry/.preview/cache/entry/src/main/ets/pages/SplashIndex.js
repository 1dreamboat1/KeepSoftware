import UserPrivacyDialog from '@bundle:com.example.baizhankeep/entry/ets/dialog/UserPrivacyDialog';
import data_preferences from '@ohos:data.preferences';
import Logger from '@bundle:com.example.baizhankeep/entry/ets/utils/Logger';
import router from '@ohos:router';
//定义常量存储首选项中的键
const H_STORE = 'BaiZhanKeepStore';
const IS_PRIVACY = 'isPrivacy';
class SplashIndex extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.context = getContext(this);
        this.dialogController = new CustomDialogController({
            builder: () => {
                let jsDialog = new UserPrivacyDialog(this, {
                    cancel: () => { this.exitApp(); },
                    confirm: () => { this.onConfirm(); }
                });
                jsDialog.setController(this.dialogController);
                ViewPU.create(jsDialog);
            }
        }, this);
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.context !== undefined) {
            this.context = params.context;
        }
        if (params.dialogController !== undefined) {
            this.dialogController = params.dialogController;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    onConfirm() {
        //定义首选项
        let preferences = data_preferences.getPreferences(this.context, H_STORE);
        //异步处理首选项中的数据
        preferences.then((res) => {
            //记录用户数据到首选项
            res.put(IS_PRIVACY, true).then(() => {
                res.flush();
                //记录日志
                Logger.debug('SplashIndex', 'isPrivacy记录成功');
                this.jumpToMain();
            }).catch((err) => {
                Logger.error('SplashIndex', 'isPrivacy记录失败，原因：' + err);
            });
        });
    }
    exitApp() {
        this.context.terminateSelf();
    }
    aboutToAppear() {
        let preferences = data_preferences.getPreferences(this.context, H_STORE);
        preferences.then((res) => {
            res.get(IS_PRIVACY, false).then((isPrivate) => {
                //判断传入参数值
                if (isPrivate === true) {
                    //说明用户已经点击过同意
                    this.jumpToMain();
                }
                else {
                    //弹出弹窗
                    this.dialogController.open();
                }
            });
        });
    }
    jumpToMain() {
        setTimeout(() => {
            router.replaceUrl({ url: "pages/MainIndex" });
        }, 2000);
    }
    aboutToDisappear() {
        clearTimeout();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/SplashIndex.ets(71:5)");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundImage({ "id": 16777280, "type": 20000, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" });
            Column.backgroundImageSize({ width: '100%', height: '100%' });
            Column.backgroundImagePosition({ x: 0, y: 0 });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777217, "type": 20000, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" });
            Image.debugLine("pages/SplashIndex.ets(72:7)");
            Image.width(100);
            Image.margin({ top: 120 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('欢迎进入百战健身');
            Text.debugLine("pages/SplashIndex.ets(75:7)");
            Text.fontSize(15);
            Text.fontColor('#182431');
            Text.fontWeight(700);
            Text.letterSpacing(0.1);
            Text.opacity(0.6);
            Text.margin({ top: 20, bottom: 140 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777219, "type": 20000, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" });
            Image.debugLine("pages/SplashIndex.ets(82:7)");
            Image.width('80%');
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new SplashIndex(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=SplashIndex.js.map