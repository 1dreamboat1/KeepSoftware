export default class UserPrivacyDialog extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.controller = new CustomDialogController({
            builder: ''
        }, this);
        this.cancel = () => { };
        this.confirm = () => { };
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
        if (params.cancel !== undefined) {
            this.cancel = params.cancel;
        }
        if (params.confirm !== undefined) {
            this.confirm = params.confirm;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    setController(ctr) {
        this.controller = ctr;
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 10 });
            Column.debugLine("dialog/UserPrivacyDialog.ets(8:5)");
            Column.width('80%');
            Column.height('75%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create({ "id": 16777245, "type": 10003, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" });
            Text.debugLine("dialog/UserPrivacyDialog.ets(9:7)");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bolder);
            Text.margin({ top: 8, bottom: 5 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create();
            Text.debugLine("dialog/UserPrivacyDialog.ets(13:7)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Span.create({ "id": 16777242, "type": 10003, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" });
            Span.debugLine("dialog/UserPrivacyDialog.ets(14:9)");
            if (!isInitialRender) {
                Span.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create();
            Text.debugLine("dialog/UserPrivacyDialog.ets(16:7)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Span.create({ "id": 16777244, "type": 10003, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" });
            Span.debugLine("dialog/UserPrivacyDialog.ets(17:9)");
            if (!isInitialRender) {
                Span.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Span.create({ "id": 16777237, "type": 10003, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" });
            Span.debugLine("dialog/UserPrivacyDialog.ets(18:9)");
            Span.fontColor({ "id": 16777259, "type": 10001, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" });
            if (!isInitialRender) {
                Span.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Span.create({ "id": 16777243, "type": 10003, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" });
            Span.debugLine("dialog/UserPrivacyDialog.ets(20:9)");
            if (!isInitialRender) {
                Span.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Span.create({ "id": 16777239, "type": 10003, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" });
            Span.debugLine("dialog/UserPrivacyDialog.ets(21:9)");
            Span.fontColor({ "id": 16777259, "type": 10001, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" });
            if (!isInitialRender) {
                Span.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Span.create({ "id": 16777241, "type": 10003, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" });
            Span.debugLine("dialog/UserPrivacyDialog.ets(23:9)");
            if (!isInitialRender) {
                Span.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create();
            Text.debugLine("dialog/UserPrivacyDialog.ets(25:7)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Span.create({ "id": 16777240, "type": 10003, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" });
            Span.debugLine("dialog/UserPrivacyDialog.ets(26:9)");
            if (!isInitialRender) {
                Span.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel('同意');
            Button.debugLine("dialog/UserPrivacyDialog.ets(28:7)");
            Button.fontColor(Color.White);
            Button.backgroundColor("#ff06ae27");
            Button.width(150);
            Button.onClick(() => {
                this.confirm();
                this.controller.close();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel('不同意');
            Button.debugLine("dialog/UserPrivacyDialog.ets(36:7)");
            Button.fontColor("#d09d9d9d");
            Button.backgroundColor("#412ef550");
            Button.width(150);
            Button.onClick(() => {
                this.cancel();
                this.controller.close();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
if (getPreviewComponentFlag()) {
    previewComponent();
}
else {
    storePreviewComponents(1, "UserPrivacyDialog", new UserPrivacyDialog(undefined, {}));
}
//# sourceMappingURL=UserPrivacyDialog.js.map