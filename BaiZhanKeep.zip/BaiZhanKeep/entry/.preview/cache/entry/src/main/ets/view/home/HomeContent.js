import DateDialog from '@bundle:com.example.baizhankeep/entry/ets/dialog/DateDialog';
import DateUtil from '@bundle:com.example.baizhankeep/entry/ets/utils/DateUtil';
export default class HomeContent extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__date = this.createStorageProp('date', DateUtil.beginTimeOfDay(new Date()), "date");
        this.controller = new CustomDialogController({
            builder: () => {
                let jsDialog = new DateDialog(this, { date: new Date(this.date) });
                jsDialog.setController(this.controller);
                ViewPU.create(jsDialog);
            }
        }, this);
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        this.__date.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get date() {
        return this.__date.get();
    }
    set date(newValue) {
        this.__date.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("view/home/HomeContent.ets(15:5)");
            Column.width('100%');
            Column.height('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("view/home/HomeContent.ets(16:7)");
            Column.backgroundImage({ "id": 16777230, "type": 20000, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" });
            Column.backgroundImageSize({ width: '100%', height: 300 });
            Column.width('100%');
            Column.height('40%');
            Column.alignItems(HorizontalAlign.Start);
            Column.borderRadius({ bottomLeft: 20, bottomRight: 20 });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('百战健身');
            Text.debugLine("view/home/HomeContent.ets(17:9)");
            Text.fontSize(25);
            Text.fontWeight(600);
            Text.margin({ top: 10, bottom: 100, left: 20 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/home/HomeContent.ets(22:9)");
            Row.width('90%');
            Row.height(50);
            Row.backgroundColor(Color.White);
            Row.margin({ left: 19, top: 90 });
            Row.borderRadius(20);
            Row.justifyContent(FlexAlign.Center);
            Row.onClick(() => {
                this.controller.open();
            });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(DateUtil.formatDate(this.date));
            Text.debugLine("view/home/HomeContent.ets(23:11)");
            Text.fontSize(15);
            Text.fontWeight(500);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777247, "type": 20000, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" });
            Image.debugLine("view/home/HomeContent.ets(26:11)");
            Image.width(20);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        Column.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
if (getPreviewComponentFlag()) {
    previewComponent();
}
else {
    storePreviewComponents(1, "HomeContent", new HomeContent(undefined, {}));
}
//# sourceMappingURL=HomeContent.js.map