import DateDialog from '@bundle:com.example.baizhankeep/entry/ets/dialog/DateDialog';
function __Text__textStyle(color, fw) {
    Text.fontSize(20);
    Text.fontWeight(fw);
    Text.fontColor(color);
}
class AchievementTop extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__value = new ObservedPropertySimplePU(1930, this, "value");
        this.__task = new ObservedPropertySimplePU(3500
        // @StorageProp('date') date: number = DateUtil.beginTimeOfDay(new Date())
        , this, "task");
        this.controller = new CustomDialogController({
            builder: () => {
                let jsDialog = new DateDialog(this, { date: new Date() });
                jsDialog.setController(this.
                // @StorageProp('date') date: number = DateUtil.beginTimeOfDay(new Date())
                controller);
                ViewPU.create(jsDialog);
            }
        }, this);
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.value !== undefined) {
            this.value = params.value;
        }
        if (params.task !== undefined) {
            this.task = params.task;
        }
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__value.purgeDependencyOnElmtId(rmElmtId);
        this.__task.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__value.aboutToBeDeleted();
        this.__task.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get value() {
        return this.__value.get();
    }
    set value(newValue) {
        this.__value.set(newValue);
    }
    get task() {
        return this.__task.get();
    }
    set task(newValue) {
        this.__task.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("view/achievement/AchievementTop.ets(21:5)");
            Column.width('100%');
            Column.height('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 5 });
            Column.debugLine("view/achievement/AchievementTop.ets(22:7)");
            Column.width('95%');
            Column.margin({ top: 30, bottom: 10 });
            Column.alignItems(HorizontalAlign.Start);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('2024年04月29日');
            Text.debugLine("view/achievement/AchievementTop.ets(23:9)");
            Text.fontSize(15);
            Text.fontColor({ "id": 16777257, "type": 10001, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" });
            Text.onClick(() => {
                this.controller.open();
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('健身记录');
            Text.debugLine("view/achievement/AchievementTop.ets(29:9)");
            __Text__textStyle(Color.White, 800);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/achievement/AchievementTop.ets(35:7)");
            Row.backgroundColor({ "id": 16777257, "type": 10001, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" });
            Row.width('95%');
            Row.height(190);
            Row.borderRadius(15);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 5 });
            Column.debugLine("view/achievement/AchievementTop.ets(36:9)");
            Column.alignItems(HorizontalAlign.Start);
            Column.margin({ left: 5 });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('运动消耗');
            Text.debugLine("view/achievement/AchievementTop.ets(37:11)");
            __Text__textStyle(Color.White, 500);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.value + '/' + this.task + '千卡');
            Text.debugLine("view/achievement/AchievementTop.ets(39:11)");
            __Text__textStyle({ "id": 16777266, "type": 10001, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" }, 800);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('距离目标');
            Text.debugLine("view/achievement/AchievementTop.ets(41:11)");
            __Text__textStyle(Color.White, 500);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create((this.task - this.value) + '千卡');
            Text.debugLine("view/achievement/AchievementTop.ets(43:11)");
            __Text__textStyle({ "id": 16777261, "type": 10001, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" }, 800);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Progress.create({
                value: this.value,
                total: this.task,
                type: ProgressType.Ring
            });
            Progress.debugLine("view/achievement/AchievementTop.ets(48:9)");
            Progress.color({ "id": 16777261, "type": 10001, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" });
            Progress.backgroundColor({ "id": 16777260, "type": 10001, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" });
            Progress.width('50%');
            Progress.height('95%');
            Progress.style({ strokeWidth: 25 });
            if (!isInitialRender) {
                Progress.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
if (getPreviewComponentFlag()) {
    previewComponent();
}
else {
    storePreviewComponents(1, "AchievementTop", new AchievementTop(undefined, {}));
}
//# sourceMappingURL=AchievementTop.js.map