export default class DateDialog extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.controller = undefined;
        this.date = new Date();
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
        if (params.date !== undefined) {
            this.date = params.date;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    setController(ctr) {
        this.controller = ctr;
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("dialog/DateDialog.ets(7:5)");
            Column.padding(12);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            DatePicker.create({
                start: new Date('2020-01-01'),
                end: new Date(),
                selected: this.date
            });
            DatePicker.debugLine("dialog/DateDialog.ets(8:7)");
            DatePicker.onChange((value) => {
                this.date.setFullYear(value.year, value.month, value.day);
            });
            if (!isInitialRender) {
                DatePicker.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        DatePicker.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create({ space: 20 });
            Row.debugLine("dialog/DateDialog.ets(16:7)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel('取消');
            Button.debugLine("dialog/DateDialog.ets(17:9)");
            Button.width(120);
            Button.backgroundColor({ "id": 16777258, "type": 10001, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" });
            Button.onClick(() => {
                this.controller.close();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel('确定');
            Button.debugLine("dialog/DateDialog.ets(23:9)");
            Button.width(120);
            Button.backgroundColor({ "id": 16777266, "type": 10001, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" });
            Button.onClick(() => {
                //将日期保存到全局
                AppStorage.SetOrCreate('date', this.date.getTime());
                //关闭弹窗
                this.controller.close();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=DateDialog.js.map