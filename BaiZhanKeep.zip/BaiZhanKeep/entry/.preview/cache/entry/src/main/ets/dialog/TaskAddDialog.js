function __GridItem__btnStyle() {
    GridItem.backgroundColor(Color.White);
    GridItem.opacity(0.7);
    GridItem.height(50);
    GridItem.borderRadius(15);
}
export default class TaskAddDialog extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__show = new ObservedPropertySimplePU(true, this, "show");
        this.numberArr = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '.'];
        this.controller = undefined;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.show !== undefined) {
            this.show = params.show;
        }
        if (params.numberArr !== undefined) {
            this.numberArr = params.numberArr;
        }
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__show.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__show.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get show() {
        return this.__show.get();
    }
    set show(newValue) {
        this.__show.set(newValue);
    }
    setController(ctr) {
        this.controller = ctr;
    }
    saveBtn(text, color, onClick, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild();
            Button.debugLine("dialog/TaskAddDialog.ets(24:5)");
            Button.width(80);
            Button.height(50);
            Button.type(ButtonType.Normal);
            Button.backgroundColor(color);
            Button.borderRadius(5);
            Button.padding({ left: 3, right: 3 });
            Button.onClick(onClick);
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(text);
            Text.debugLine("dialog/TaskAddDialog.ets(25:7)");
            Text.fontSize(20);
            Text.fontWeight(800);
            Text.opacity(0.9);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Button.pop();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("dialog/TaskAddDialog.ets(40:5)");
            Column.width('95%');
            Column.height('95%');
            Column.alignItems(HorizontalAlign.Center);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("dialog/TaskAddDialog.ets(41:7)");
            Row.width('95%');
            Row.justifyContent(FlexAlign.End);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('2024年05月5日');
            Text.debugLine("dialog/TaskAddDialog.ets(42:9)");
            Text.fontSize(15);
            Text.fontWeight(600);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Blank.create(10);
            Blank.debugLine("dialog/TaskAddDialog.ets(45:9)");
            if (!isInitialRender) {
                Blank.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Blank.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild();
            Button.debugLine("dialog/TaskAddDialog.ets(46:9)");
            Button.width(20);
            Button.height(20);
            Button.backgroundColor(Color.Red);
            Button.padding({ bottom: 5 });
            Button.onClick(() => {
                this.controller.close();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('x');
            Text.debugLine("dialog/TaskAddDialog.ets(47:11)");
            Text.fontSize(15);
            Text.fontColor(Color.White);
            Text.fontWeight(800);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Button.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 10 });
            Column.debugLine("dialog/TaskAddDialog.ets(62:7)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777229, "type": 20000, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" });
            Image.debugLine("dialog/TaskAddDialog.ets(63:9)");
            Image.width(90);
            Image.height(90);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('游泳');
            Text.debugLine("dialog/TaskAddDialog.ets(66:9)");
            Text.fontSize(20);
            Text.fontWeight(700);
            Text.backgroundColor({ "id": 16777258, "type": 10001, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("dialog/TaskAddDialog.ets(70:9)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create();
            TextInput.debugLine("dialog/TaskAddDialog.ets(71:11)");
            TextInput.width('35%');
            TextInput.fontSize(35);
            TextInput.fontColor({ "id": 16777265, "type": 10001, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" });
            TextInput.caretColor(Color.Transparent);
            TextInput.textAlign(TextAlign.Center);
            TextInput.copyOption(CopyOptions.None);
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('/小时');
            Text.debugLine("dialog/TaskAddDialog.ets(78:11)");
            Text.fontSize(35);
            Text.opacity(0.7);
            Text.fontWeight(800);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Panel.create(this.show);
            Panel.debugLine("dialog/TaskAddDialog.ets(83:9)");
            Panel.mode(PanelMode.Half);
            Panel.halfHeight(1050);
            Panel.type(PanelType.Temporary);
            Panel.dragBar(false);
            Panel.width('100%');
            if (!isInitialRender) {
                Panel.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("dialog/TaskAddDialog.ets(84:11)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Grid.create();
            Grid.debugLine("dialog/TaskAddDialog.ets(85:13)");
            Grid.columnsTemplate('1fr 1fr 1fr');
            Grid.columnsGap(5);
            Grid.rowsGap(8);
            Grid.width('95%');
            Grid.padding({ top: 15 });
            if (!isInitialRender) {
                Grid.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                {
                    const isLazyCreate = true && (Grid.willUseProxy() === true);
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        GridItem.create(deepRenderFunction, isLazyCreate);
                        __GridItem__btnStyle();
                        GridItem.onClick(() => {
                        });
                        GridItem.debugLine("dialog/TaskAddDialog.ets(87:17)");
                        if (!isInitialRender) {
                            GridItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const observedShallowRender = () => {
                        this.observeComponentCreation(itemCreation);
                        GridItem.pop();
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation(itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item);
                            Text.debugLine("dialog/TaskAddDialog.ets(88:19)");
                            Text.fontSize(20);
                            Text.fontWeight(500);
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        GridItem.pop();
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.updateFuncByElmtId.set(elmtId, itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item);
                            Text.debugLine("dialog/TaskAddDialog.ets(88:19)");
                            Text.fontSize(20);
                            Text.fontWeight(500);
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        GridItem.pop();
                    };
                    if (isLazyCreate) {
                        observedShallowRender();
                    }
                    else {
                        observedDeepRender();
                    }
                }
            };
            this.forEachUpdateFunction(elmtId, this.numberArr, forEachItemGenFunction);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        {
            const isLazyCreate = true && (Grid.willUseProxy() === true);
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                GridItem.create(deepRenderFunction, isLazyCreate);
                __GridItem__btnStyle();
                GridItem.onClick(() => {
                });
                GridItem.debugLine("dialog/TaskAddDialog.ets(97:15)");
                if (!isInitialRender) {
                    GridItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const observedShallowRender = () => {
                this.observeComponentCreation(itemCreation);
                GridItem.pop();
            };
            const observedDeepRender = () => {
                this.observeComponentCreation(itemCreation);
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create('删除');
                    Text.debugLine("dialog/TaskAddDialog.ets(98:17)");
                    Text.fontSize(20);
                    Text.fontWeight(500);
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                GridItem.pop();
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.updateFuncByElmtId.set(elmtId, itemCreation);
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create('删除');
                    Text.debugLine("dialog/TaskAddDialog.ets(98:17)");
                    Text.fontSize(20);
                    Text.fontWeight(500);
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                GridItem.pop();
            };
            if (isLazyCreate) {
                observedShallowRender();
            }
            else {
                observedDeepRender();
            }
        }
        {
            const isLazyCreate = true && (Grid.willUseProxy() === true);
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                GridItem.create(deepRenderFunction, isLazyCreate);
                GridItem.columnStart(1);
                GridItem.columnEnd(3);
                __GridItem__btnStyle();
                GridItem.debugLine("dialog/TaskAddDialog.ets(106:15)");
                if (!isInitialRender) {
                    GridItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const observedShallowRender = () => {
                this.observeComponentCreation(itemCreation);
                GridItem.pop();
            };
            const observedDeepRender = () => {
                this.observeComponentCreation(itemCreation);
                this.saveBtn.bind(this)('确定', { "id": 16777256, "type": 10001, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" }, () => this.show = false);
                GridItem.pop();
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.updateFuncByElmtId.set(elmtId, itemCreation);
                this.saveBtn.bind(this)('确定', { "id": 16777256, "type": 10001, params: [], "bundleName": "com.example.baizhankeep", "moduleName": "entry" }, () => this.show = false);
                GridItem.pop();
            };
            if (isLazyCreate) {
                observedShallowRender();
            }
            else {
                observedDeepRender();
            }
        }
        Grid.pop();
        Column.pop();
        Panel.pop();
        Column.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
if (getPreviewComponentFlag()) {
    previewComponent();
}
else {
    storePreviewComponents(1, "TaskAddDialog", new TaskAddDialog(undefined, {}));
}
//# sourceMappingURL=TaskAddDialog.js.map